let frutas = []; // Array para armazenar as frutas
let cesto; // Objeto para o cesto
let pontuacao = 0; // Contagem de frutas no cesto
let frutasNoCesto = 0; // Quantidade de frutas atualmente no cesto
let totalFrutas = 5; // Número total de frutas para jogar
let jogoGanho = false; // Flag para controlar se o jogo foi ganho
let estadoJogo = 'inicio'; // 'inicio', 'jogando', 'ganho'

// Imagens (opcionais, você pode desenhar as formas se não tiver imagens)
let frutaImg;
let cestoImg;
let fundoImg;
let melanciaImg; // Exemplo de uma fruta específica
let bananaImg;   // Exemplo de outra fruta específica

function preload() {
  // Se tiver imagens, descomente e carregue-as aqui!
  // Exemplo:
  // frutaImg = loadImage('assets/maca.png');
  // cestoImg = loadImage('assets/cesto.png');
  // fundoImg = loadImage('assets/fundo_ceu.png');
  // melanciaImg = loadImage('assets/melancia.png');
  // bananaImg = loadImage('assets/banana.png');
}

function setup() {
  createCanvas(800, 600);
  rectMode(CENTER); // Desenha retângulos do centro (bom para o cesto)
  ellipseMode(CENTER); // Desenha elipses do centro (bom para as frutas)

  // Inicializa o cesto
  cesto = {
    x: width / 2,
    y: height - 80,
    largura: 150,
    altura: 100,
    cor: color(139, 69, 19) // Marrom
  };

  // Cria as frutas iniciais
  for (let i = 0; i < totalFrutas; i++) {
    criarNovaFruta();
  }
}

function draw() {
  // Desenha o fundo
  if (fundoImg) {
    image(fundoImg, 0, 0, width, height);
  } else {
    background(135, 206, 235); // Azul céu
  }

  if (estadoJogo === 'inicio') {
    desenhaTelaInicio();
  } else if (estadoJogo === 'jogando') {
    logicaJogo();
    desenhaElementosJogo();
    desenhaInterface();
  } else if (estadoJogo === 'ganho') {
    desenhaTelaGanho();
  }
}

function desenhaTelaInicio() {
  fill(0, 0, 0, 150); // Fundo semi-transparente
  rect(width / 2, height / 2, width, height);

  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("Arremesso de Frutas!", width / 2, height / 2 - 50);

  textSize(24);
  text("Pressione ESPAÇO para começar", width / 2, height / 2 + 30);
  text("Clique e arraste a fruta para jogar!", width / 2, height / 2 + 70);
}

function logicaJogo() {
  if (frutasNoCesto === totalFrutas) {
    jogoGanho = true;
    estadoJogo = 'ganho';
    return; // Sai da função draw se o jogo foi ganho
  }

  // Atualiza e desenha as frutas
  for (let i = frutas.length - 1; i >= 0; i--) {
    let fruta = frutas[i];

    if (fruta.arremessada) {
      fruta.velocidadeY += fruta.gravidade;
      fruta.x += fruta.velocidadeX;
      fruta.y += fruta.velocidadeY;

      // Se a fruta sair da tela por baixo, ela "caiu" e não foi pro cesto
      if (fruta.y > height + fruta.diametro) {
        frutas.splice(i, 1); // Remove a fruta que caiu
        criarNovaFruta(); // Cria uma nova fruta para substituir
        console.log("Fruta caiu! Nova fruta criada.");
        continue; // Pula para a próxima fruta no loop
      }

      // Verifica colisão com o cesto
      if (
        fruta.x > cesto.x - cesto.largura / 2 &&
        fruta.x < cesto.x + cesto.largura / 2 &&
        fruta.y > cesto.y - cesto.altura / 2 &&
        fruta.y < cesto.y + cesto.altura / 2
      ) {
        // Fruta caiu no cesto!
        if (!fruta.noCesto) { // Verifica se já não foi contada
          frutasNoCesto++;
          console.log(`Fruta no cesto! Total: ${frutasNoCesto}/${totalFrutas}`);
          fruta.noCesto = true; // Marca como "no cesto" para não contar de novo
          frutas.splice(i, 1); // Remove a fruta do array para não processá-la mais
          if (frutasNoCesto < totalFrutas) {
            criarNovaFruta(); // Cria uma nova fruta se ainda faltam frutas
          }
        }
      }
    }
  }
}

function desenhaElementosJogo() {
  // Desenha o cesto
  if (cestoImg) {
    image(cestoImg, cesto.x - cesto.largura / 2, cesto.y - cesto.altura / 2, cesto.largura, cesto.altura);
  } else {
    fill(cesto.cor);
    rect(cesto.x, cesto.y, cesto.largura, cesto.altura);
    // Adiciona uma pequena abertura para simular o cesto
    stroke(cesto.cor);
    strokeWeight(5);
    line(cesto.x - cesto.largura / 2 + 10, cesto.y - cesto.altura / 2 + 5, cesto.x + cesto.largura / 2 - 10, cesto.y - cesto.altura / 2 + 5);
    noStroke();
  }

  // Desenha as frutas
  for (let fruta of frutas) {
    // Escolhe a imagem da fruta ou desenha a forma
    let imgFruta;
    if (fruta.tipo === 'melancia' && melanciaImg) {
      imgFruta = melanciaImg;
    } else if (fruta.tipo === 'banana' && bananaImg) {
      imgFruta = bananaImg;
    } else if (frutaImg) { // Imagem genérica de fruta
      imgFruta = frutaImg;
    }

    if (imgFruta) {
      image(imgFruta, fruta.x - fruta.diametro / 2, fruta.y - fruta.diametro / 2, fruta.diametro, fruta.diametro);
    } else {
      fill(fruta.cor);
      ellipse(fruta.x, fruta.y, fruta.diametro, fruta.diametro);
      // Detalhes da fruta (como sementes para melancia)
      if (fruta.tipo === 'melancia') {
        fill(200, 50, 50); // Vermelho para a parte interna
        ellipse(fruta.x, fruta.y, fruta.diametro * 0.8, fruta.diametro * 0.8);
        fill(255); // Sementes
        ellipse(fruta.x - 5, fruta.y - 5, 2, 3);
        ellipse(fruta.x + 5, fruta.y + 5, 2, 3);
      } else if (fruta.tipo === 'banana') {
        fill(180, 180, 0); // Amarelo
        rect(fruta.x, fruta.y, fruta.diametro * 0.8, fruta.diametro * 0.4, 10); // Forma de banana arredondada
      }
    }

    // Se estiver arrastando, desenha uma linha indicando a direção do arremesso
    if (fruta.arrastando) {
      stroke(255, 0, 0); // Linha vermelha
      strokeWeight(2);
      line(fruta.origemX, fruta.origemY, mouseX, mouseY);
      noStroke();
    }
  }
}

function desenhaInterface() {
  // Mostra a pontuação
  fill(0);
  textSize(24);
  textAlign(LEFT, TOP);
  text(`Frutas no cesto: ${frutasNoCesto}/${totalFrutas}`, 20, 20);
}

function desenhaTelaGanho() {
  fill(0, 200, 0, 180); // Fundo verde semi-transparente
  rect(width / 2, height / 2, width, height);

  fill(255);
  textSize(64);
  textAlign(CENTER, CENTER);
  text("VOCÊ GANHOU!", width / 2, height / 2 - 30);

  textSize(32);
  text("Parabéns, todas as frutas estão no cesto!", width / 2, height / 2 + 40);
  textSize(24);
  text("Pressione R para jogar novamente", width / 2, height / 2 + 100);
}

function mousePressed() {
  if (estadoJogo === 'jogando') {
    for (let fruta of frutas) {
      // Verifica se o clique foi em uma fruta que não foi arremessada ainda
      if (!fruta.arremessada && dist(mouseX, mouseY, fruta.x, fruta.y) < fruta.diametro / 2) {
        fruta.arrastando = true;
        fruta.origemX = fruta.x; // Salva a posição inicial para desenhar a linha de arremesso
        fruta.origemY = fruta.y;
        console.log("Começou a arrastar uma fruta.");
        break; // Apenas uma fruta pode ser arrastada por vez
      }
    }
  }
}

function mouseReleased() {
  if (estadoJogo === 'jogando') {
    for (let fruta of frutas) {
      if (fruta.arrastando) {
        fruta.arrastando = false;
        fruta.arremessada = true;

        // Calcula a força e direção do arremesso
        let forcaX = (fruta.origemX - mouseX) * 0.1; // Multiplicador para ajustar a força
        let forcaY = (fruta.origemY - mouseY) * 0.1;

        // Limita a força máxima do arremesso para não ficar muito forte
        let maxForca = 15;
        forcaX = constrain(forcaX, -maxForca, maxForca);
        forcaY = constrain(forcaY, -maxForca, maxForca);

        fruta.velocidadeX = forcaX;
        fruta.velocidadeY = forcaY;
        console.log(`Fruta arremessada! Velocidade X: ${fruta.velocidadeX.toFixed(2)}, Velocidade Y: ${fruta.velocidadeY.toFixed(2)}`);
        break; // Apenas uma fruta pode ser arremessada por vez
      }
    }
  }
}

function keyPressed() {
  if (estadoJogo === 'inicio' && key === ' ') { // Espaço para iniciar o jogo
    estadoJogo = 'jogando';
    console.log("Jogo iniciado!");
  } else if (estadoJogo === 'ganho' && (key === 'r' || key === 'R')) { // R para reiniciar o jogo
    reiniciarJogo();
    console.log("Jogo reiniciado!");
  }
}

function criarNovaFruta() {
  let tiposFruta = ['melancia', 'banana', 'generica'];
  let tipoAleatorio = random(tiposFruta);
  let corAleatoria;

  if (tipoAleatorio === 'melancia') {
    corAleatoria = color(0, 150, 0); // Verde para melancia
  } else if (tipoAleatorio === 'banana') {
    corAleatoria = color(255, 255, 0); // Amarelo para banana
  } else {
    corAleatoria = color(random(100, 255), random(100, 255), random(100, 255)); // Cor aleatória
  }

  frutas.push({
    x: width / 2, // Posição inicial no centro da tela
    y: height / 2,
    diametro: 40,
    cor: corAleatoria,
    velocidadeX: 0,
    velocidadeY: 0,
    gravidade: 0.2,
    arremessada: false, // Flag para saber se a fruta foi arremessada
    arrastando: false, // Flag para saber se a fruta está sendo arrastada
    origemX: 0, // Posição de onde o clique começou para calcular a força
    origemY: 0,
    noCesto: false, // Flag para saber se a fruta já foi contada no cesto
    tipo: tipoAleatorio // Para desenhar diferentes tipos de fruta
  });
}

function reiniciarJogo() {
  frutas = [];
  pontuacao = 0;
  frutasNoCesto = 0;
  jogoGanho = false;
  estadoJogo = 'inicio'; // Volta para a tela de início

  for (let i = 0; i < totalFrutas; i++) {
    criarNovaFruta();
  }
}